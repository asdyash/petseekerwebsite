import styles from "./TypeRequiredStateDefault2.module.css";

const TypeRequiredStateDefault2 = () => {
  return (
    <div className={styles.typerequiredStatedefault}>
      <div className={styles.div}>PET YOU WANT TO ADOPT</div>
      <div className={styles.textBlock}>
        <div className={styles.text}>Text</div>
        <img
          className={styles.mdiArrowDropDownIcon}
          alt=""
          src="/mdi-arrow-drop-down.svg"
        />
      </div>
    </div>
  );
};

export default TypeRequiredStateDefault2;
