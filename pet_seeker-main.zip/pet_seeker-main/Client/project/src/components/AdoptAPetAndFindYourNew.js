import styles from "./AdoptAPetAndFindYourNew.module.css";

const AdoptAPetAndFindYourNew = () => {
  return (
    <div className={styles.adoptAPetAndFindYourNew}>
      <div className={styles.adoptAPet}>
        Adopt a pet and find your new best friend .....
      </div>
    </div>
  );
};

export default AdoptAPetAndFindYourNew;
