import styles from "./TypeRequiredStateDefault3.module.css";

const TypeRequiredStateDefault3 = () => {
  return (
    <div className={styles.typerequiredStatedefault}>
      <div className={styles.div}>PET YOU WANT TO REHOME</div>
      <div className={styles.textBlock}>
        <div className={styles.text}>Text</div>
        <img
          className={styles.mdiArrowDropDownIcon}
          alt=""
          src="/mdi-arrow-drop-down.svg"
        />
      </div>
    </div>
  );
};

export default TypeRequiredStateDefault3;
