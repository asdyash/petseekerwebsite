import styles from "./TypeRequiredStateDefault1.module.css";

const TypeRequiredStateDefault1 = () => {
  return (
    <div className={styles.typerequiredStatedefault}>
      <div className={styles.div}>PASSWORD</div>
      <input className={styles.textBlock} placeholder="Text" type="text" />
    </div>
  );
};

export default TypeRequiredStateDefault1;
